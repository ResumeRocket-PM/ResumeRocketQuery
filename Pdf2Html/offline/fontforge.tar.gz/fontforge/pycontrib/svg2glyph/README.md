# Testing

Running `make` in the current directory will translate all the SVG icons in `SVG/` to FontForge glyphs.

The resulting font can be opened in FontForge with `fontforge SFDir/`.

# Licenses

- Script: BSD.
- SVG icons: CC BY-SA.

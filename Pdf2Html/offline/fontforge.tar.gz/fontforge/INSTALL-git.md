To install from git, you must first run the `autogen.sh` script, then configure and compile as normal:

```
./autogen.sh;
./configure;
make;
sudo make install;
```

#include "fontforge.h"

int main()
{
    InitSimpleStuff();
    return 0;
}
